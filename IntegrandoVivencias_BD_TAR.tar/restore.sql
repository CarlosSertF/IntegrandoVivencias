--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE integrando_vivencias_db;
--
-- Name: integrando_vivencias_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE integrando_vivencias_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE integrando_vivencias_db OWNER TO postgres;

\unrestrict (null)
\connect integrando_vivencias_db
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anamnese; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.anamnese (
    id bigint NOT NULL,
    data_realizacao timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    queixa_atual text,
    tem_laudo boolean DEFAULT false,
    laudo_descricao text,
    toma_medicacao boolean DEFAULT false,
    medicacao_descricao text,
    faz_acompanhamento boolean DEFAULT false,
    acompanhamento_descricao text,
    tem_dificuldade_fala boolean DEFAULT false,
    preferencias_brincadeiras text,
    paciente_id bigint NOT NULL,
    funcionario_id bigint,
    descricao_acompanhamento text,
    descricao_laudo text,
    descricao_medicacao text,
    usuario_id bigint
);


ALTER TABLE public.anamnese OWNER TO postgres;

--
-- Name: anamnese_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.anamnese_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anamnese_id_seq OWNER TO postgres;

--
-- Name: anamnese_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.anamnese_id_seq OWNED BY public.anamnese.id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    id bigint NOT NULL,
    nome character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    senha character varying(255) NOT NULL,
    cargo character varying(50)
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.funcionario_id_seq OWNER TO postgres;

--
-- Name: funcionario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_id_seq OWNED BY public.funcionario.id;


--
-- Name: info_escolar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.info_escolar (
    id bigint NOT NULL,
    nome_escola character varying(255),
    turno character varying(255),
    ano_escolar character varying(255),
    paciente_id bigint NOT NULL
);


ALTER TABLE public.info_escolar OWNER TO postgres;

--
-- Name: info_escolar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.info_escolar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.info_escolar_id_seq OWNER TO postgres;

--
-- Name: info_escolar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.info_escolar_id_seq OWNED BY public.info_escolar.id;


--
-- Name: paciente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paciente (
    id bigint NOT NULL,
    nome character varying(255) NOT NULL,
    data_nascimento date NOT NULL,
    data_cadastro date DEFAULT CURRENT_TIMESTAMP,
    usuario_id bigint
);


ALTER TABLE public.paciente OWNER TO postgres;

--
-- Name: paciente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paciente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.paciente_id_seq OWNER TO postgres;

--
-- Name: paciente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paciente_id_seq OWNED BY public.paciente.id;


--
-- Name: pacientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pacientes (
    id bigint NOT NULL,
    data_cadastro date NOT NULL,
    data_nascimento date NOT NULL,
    nome character varying(255) NOT NULL,
    usuario_id bigint
);


ALTER TABLE public.pacientes OWNER TO postgres;

--
-- Name: pacientes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.pacientes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pacientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: responsavel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.responsavel (
    id bigint NOT NULL,
    nome character varying(255) NOT NULL,
    telefone character varying(255),
    relacao character varying(255),
    email character varying(255),
    paciente_id bigint NOT NULL
);


ALTER TABLE public.responsavel OWNER TO postgres;

--
-- Name: responsavel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.responsavel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.responsavel_id_seq OWNER TO postgres;

--
-- Name: responsavel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.responsavel_id_seq OWNED BY public.responsavel.id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    id bigint NOT NULL,
    cargo character varying(255),
    email character varying(255) NOT NULL,
    nome character varying(255) NOT NULL,
    senha character varying(255) NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.usuario ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id bigint NOT NULL,
    cargo character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    nome character varying(255) NOT NULL,
    senha character varying(255) NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.usuarios ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: anamnese id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese ALTER COLUMN id SET DEFAULT nextval('public.anamnese_id_seq'::regclass);


--
-- Name: funcionario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN id SET DEFAULT nextval('public.funcionario_id_seq'::regclass);


--
-- Name: info_escolar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.info_escolar ALTER COLUMN id SET DEFAULT nextval('public.info_escolar_id_seq'::regclass);


--
-- Name: paciente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente ALTER COLUMN id SET DEFAULT nextval('public.paciente_id_seq'::regclass);


--
-- Name: responsavel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.responsavel ALTER COLUMN id SET DEFAULT nextval('public.responsavel_id_seq'::regclass);


--
-- Data for Name: anamnese; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.anamnese (id, data_realizacao, queixa_atual, tem_laudo, laudo_descricao, toma_medicacao, medicacao_descricao, faz_acompanhamento, acompanhamento_descricao, tem_dificuldade_fala, preferencias_brincadeiras, paciente_id, funcionario_id, descricao_acompanhamento, descricao_laudo, descricao_medicacao, usuario_id) FROM stdin;
\.
COPY public.anamnese (id, data_realizacao, queixa_atual, tem_laudo, laudo_descricao, toma_medicacao, medicacao_descricao, faz_acompanhamento, acompanhamento_descricao, tem_dificuldade_fala, preferencias_brincadeiras, paciente_id, funcionario_id, descricao_acompanhamento, descricao_laudo, descricao_medicacao, usuario_id) FROM '$$PATH$$/5091.dat';

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funcionario (id, nome, email, senha, cargo) FROM stdin;
\.
COPY public.funcionario (id, nome, email, senha, cargo) FROM '$$PATH$$/5083.dat';

--
-- Data for Name: info_escolar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.info_escolar (id, nome_escola, turno, ano_escolar, paciente_id) FROM stdin;
\.
COPY public.info_escolar (id, nome_escola, turno, ano_escolar, paciente_id) FROM '$$PATH$$/5089.dat';

--
-- Data for Name: paciente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paciente (id, nome, data_nascimento, data_cadastro, usuario_id) FROM stdin;
\.
COPY public.paciente (id, nome, data_nascimento, data_cadastro, usuario_id) FROM '$$PATH$$/5085.dat';

--
-- Data for Name: pacientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pacientes (id, data_cadastro, data_nascimento, nome, usuario_id) FROM stdin;
\.
COPY public.pacientes (id, data_cadastro, data_nascimento, nome, usuario_id) FROM '$$PATH$$/5095.dat';

--
-- Data for Name: responsavel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.responsavel (id, nome, telefone, relacao, email, paciente_id) FROM stdin;
\.
COPY public.responsavel (id, nome, telefone, relacao, email, paciente_id) FROM '$$PATH$$/5087.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (id, cargo, email, nome, senha) FROM stdin;
\.
COPY public.usuario (id, cargo, email, nome, senha) FROM '$$PATH$$/5093.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, cargo, email, nome, senha) FROM stdin;
\.
COPY public.usuarios (id, cargo, email, nome, senha) FROM '$$PATH$$/5097.dat';

--
-- Name: anamnese_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.anamnese_id_seq', 1, false);


--
-- Name: funcionario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_id_seq', 1, false);


--
-- Name: info_escolar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.info_escolar_id_seq', 1, false);


--
-- Name: paciente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paciente_id_seq', 6, true);


--
-- Name: pacientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pacientes_id_seq', 5, true);


--
-- Name: responsavel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.responsavel_id_seq', 1, false);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_id_seq', 4, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: anamnese anamnese_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese
    ADD CONSTRAINT anamnese_pkey PRIMARY KEY (id);


--
-- Name: funcionario funcionario_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_email_key UNIQUE (email);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (id);


--
-- Name: info_escolar info_escolar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.info_escolar
    ADD CONSTRAINT info_escolar_pkey PRIMARY KEY (id);


--
-- Name: paciente paciente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente
    ADD CONSTRAINT paciente_pkey PRIMARY KEY (id);


--
-- Name: pacientes pacientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT pacientes_pkey PRIMARY KEY (id);


--
-- Name: responsavel responsavel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.responsavel
    ADD CONSTRAINT responsavel_pkey PRIMARY KEY (id);


--
-- Name: usuario uk5171l57faosmj8myawaucatdw; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT uk5171l57faosmj8myawaucatdw UNIQUE (email);


--
-- Name: usuarios ukkfsp0s1tflm1cwlj8idhqsad0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT ukkfsp0s1tflm1cwlj8idhqsad0 UNIQUE (email);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: pacientes fk16txdjlnjhrx8dcac5bhjenkh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT fk16txdjlnjhrx8dcac5bhjenkh FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: anamnese fk7ep4rkpu2iqikja6tmwuhlv03; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese
    ADD CONSTRAINT fk7ep4rkpu2iqikja6tmwuhlv03 FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: anamnese fk_anamnese_funcionario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese
    ADD CONSTRAINT fk_anamnese_funcionario FOREIGN KEY (funcionario_id) REFERENCES public.funcionario(id) ON DELETE SET NULL;


--
-- Name: anamnese fk_anamnese_paciente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese
    ADD CONSTRAINT fk_anamnese_paciente FOREIGN KEY (paciente_id) REFERENCES public.paciente(id) ON DELETE CASCADE;


--
-- Name: info_escolar fk_escola_paciente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.info_escolar
    ADD CONSTRAINT fk_escola_paciente FOREIGN KEY (paciente_id) REFERENCES public.paciente(id) ON DELETE CASCADE;


--
-- Name: paciente fk_paciente_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente
    ADD CONSTRAINT fk_paciente_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: paciente fk_paciente_usuario_final; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paciente
    ADD CONSTRAINT fk_paciente_usuario_final FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: pacientes fk_pacientes_usuario_correto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pacientes
    ADD CONSTRAINT fk_pacientes_usuario_correto FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: responsavel fk_responsavel_paciente; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.responsavel
    ADD CONSTRAINT fk_responsavel_paciente FOREIGN KEY (paciente_id) REFERENCES public.paciente(id) ON DELETE CASCADE;


--
-- Name: anamnese fkj97i4x023kpbpawp7vny123v7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese
    ADD CONSTRAINT fkj97i4x023kpbpawp7vny123v7 FOREIGN KEY (paciente_id) REFERENCES public.pacientes(id);


--
-- Name: anamnese fkqcfub53fxdl9rkhjx1kanxgpj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anamnese
    ADD CONSTRAINT fkqcfub53fxdl9rkhjx1kanxgpj FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- PostgreSQL database dump complete
--

